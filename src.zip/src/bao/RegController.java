package bao;
import dao.Register;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import java.util.*;
@Controller
public class RegController {
@RequestMapping("reg")
public ModelAndView regLoad()
{
	return new ModelAndView("reg","command",new Register());
}
@RequestMapping(value = "reglogic", method = RequestMethod.POST)
public ModelAndView reglogic(@ModelAttribute("SpringbasicExample")Register obj, ModelMap model) {

	Configuration cfg = new Configuration();
    cfg.configure("hibernate.cfg.xml");
    SessionFactory sf = cfg.buildSessionFactory();
    Session s = sf.openSession();
    Transaction tx = s.beginTransaction();
    Register rg = new Register();
    rg.setEmailid(obj.getEmailid());
    rg.setPassword(obj.getPassword());
    s.save(rg);
    tx.commit();
	return new ModelAndView("regresult");
}
@RequestMapping("login")
public ModelAndView loginLoad()
{
	return new ModelAndView("login","command",new Register());
}
@RequestMapping(value = "loginlogic", method = RequestMethod.POST)
public ModelAndView loginlogic(@ModelAttribute("SpringbasicExample")Register obj, ModelMap model) {

	Configuration cfg = new Configuration();
    cfg.configure("hibernate.cfg.xml");
    SessionFactory sf = cfg.buildSessionFactory();
    Session s = sf.openSession();
    Query q = s.createQuery("from Register r where r.emailid=? and r.password=?");
    q.setString(0,obj.getEmailid());
    q.setString(1,obj.getPassword());
    List lst= q.list();
    String res="";
    if(lst.size()>0)
    {
    	
    	return new ModelAndView("redirect:add");
    }
    else
    {
    	res = "Invalid userid and password";
    	return new ModelAndView("loginresult","key",res);
    }
    
}
}
